import { View, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native'

const HeaderComponent = ({ canGoBack = true }) => {
  const navigation = useNavigation()
  return (
    <View
      style={{
        width: '100%',
        paddingVertical: 10,
        backgroundColor: '#0b1147',
        justifyContent: 'center',
        alignItems: 'center',
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        paddingTop: 60
      }}>
      <Image
        source={require('../assets/logo.png')}
        style={{ height: 40 }}
        resizeMode="contain"
      />
      {canGoBack && (
        <TouchableOpacity
          style={{ position: 'absolute', left: 10 }}
          onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" color="white" size={25} />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default HeaderComponent;
