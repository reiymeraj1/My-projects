import MainNavigator from './navigation/MainNavigator';

export default function App() {
  return <MainNavigator />;
}
