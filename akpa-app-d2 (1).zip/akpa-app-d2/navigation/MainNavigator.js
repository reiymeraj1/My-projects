import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons'
import StudentStack from './StudentStack';
import TraineeStack from './TraineeStack';

const Tab = createBottomTabNavigator();

const MainNavigator = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen
          name="StudentTab"
          component={StudentStack}
          options={{
            tabBarLabel: 'Kursant',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="person-outline" color={color} size={size} />
            ),
          }}
        />
        <Tab.Screen
          name="TraineeTab"
          component={TraineeStack}
          options={{
            tabBarLabel: 'Qender Kursi',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="school-outline" color={color} size={size} />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default MainNavigator;
