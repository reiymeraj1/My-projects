import { createNativeStackNavigator } from '@react-navigation/native-stack';
import StudentOutputScreen from '../screens/StudentOutputScreen';
import StudentInputScreen from '../screens/StudentInputScreen';

const Stack = createNativeStackNavigator()

const StudentStack = () => {
  return(
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="StudentInput" component={StudentInputScreen} />
      <Stack.Screen name="StudentOutput" component={StudentOutputScreen} />
    </Stack.Navigator>
  )
}

export default StudentStack
