import {createNativeStackNavigator} from '@react-navigation/native-stack';
import TraineeInputScreen from '../screens/TraineeInputScreen'
import TraineeOutputScreen from '../screens/TraineeOutputScreen'

const Stack = createNativeStackNavigator()

const TraineeStack = () => {
  return(
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="TraineeInput" component={TraineeInputScreen} />
      <Stack.Screen name="TraineeOutput" component={TraineeOutputScreen} />
    </Stack.Navigator>
  )
}

export default TraineeStack
