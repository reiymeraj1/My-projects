import {Text} from 'react-native'
import HeaderComponent from '../components/HeaderComponent'

const StudentOutputScreen = () => {
  return(
    <HeaderComponent />
  )
}

export default StudentOutputScreen
