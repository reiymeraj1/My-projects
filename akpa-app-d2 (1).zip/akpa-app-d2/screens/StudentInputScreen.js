import React, { useState } from 'react';
import {
  Button,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Switch,
  Platform,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import HeaderComponent from '../components/HeaderComponent';

const StudentInputScreen = ({ navigation }) => {
  const [price, setPrice] = useState('');
  const [selectedSubsidy, setSelectedSubsidy] = useState('50');
  const [startDate, setStartDate] = useState(new Date());
  const [selectedDuration, setSelectedDuration] = useState('4');
  const [selectedInstallments, setSelectedInstallments] = useState('3');
  const [isEmployed, setIsEmployed] = useState(false);
  const [employmentDate, setEmploymentDate] = useState(new Date());

  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEmploymentDatePicker, setShowEmploymentDatePicker] =
    useState(false);

  const validateValues = () => {
    if (
      price &&
      selectedSubsidy &&
      startDate &&
      selectedDuration &&
      selectedInstallments
    ) {
      return false;
    } else return true;
  };

  const calculate = () => {
    if (!price || isNaN(price)) {
      alert('Kujdes!', 'Vendosni saktë cmimin e kursit');
      return;
    }

    const totalPrice = parseFloat(price);
    const initialSubsidy = parseFloat(selectedSubsidy);

    const parsedDuration = parseInt(selectedDuration);
    const parsedInstallments = parseInt(selectedInstallments)
  };

  // validim nese parsedDuration eshte nr negativ ose parsedInstallments esht enr negativ

  // nr i kesteve eshte me i madh se kohezgjatja

  return (
    <>
      <HeaderComponent canGoBack={false} />
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
          Përllogarit Këstet
        </Text>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>Çmimi i Kursit (ALL)</Text>
          <TextInput
            style={styles.inputStyle}
            keyboardType="numeric"
            value={price}
            onChangeText={setPrice}
          />
        </View>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>% e Subvencionit</Text>
          <Picker
            style={styles.selectStyle}
            selectedValue={selectedSubsidy}
            onValueChange={(value) => setSelectedSubsidy(value)}>
            <Picker.Item label="50%" value="50" />
            <Picker.Item label="100%" value="100" />
          </Picker>
        </View>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>Data e Fillimit</Text>
          <TouchableOpacity onPress={() => setShowStartDatePicker(true)}>
            <Text style={styles.dateStyle}>
              {startDate.toLocaleDateString()}
            </Text>
          </TouchableOpacity>
          {showStartDatePicker && (
            <DateTimePicker
              value={startDate}
              mode="date"
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              onChange={(_, selectedDate) => {
                setShowStartDatePicker(false);
                if (selectedDate) setStartDate(selectedDate);
              }}
            />
          )}
        </View>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>Kohëzgjatja e Kursit</Text>
          <Picker
            style={styles.selectStyle}
            selectedValue={selectedDuration}
            onValueChange={(value) => setSelectedDuration(value)}>
            <Picker.Item label="4" value="4" />
            <Picker.Item label="5" value="5" />
            <Picker.Item label="6" value="6" />
            <Picker.Item label="7" value="7" />
            <Picker.Item label="8" value="8" />
            <Picker.Item label="9" value="9" />
            <Picker.Item label="10" value="10" />
            <Picker.Item label="11" value="11" />
            <Picker.Item label="12" value="12" />
          </Picker>
        </View>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>Numri i Kësteve</Text>
          <Picker
            style={styles.selectStyle}
            selectedValue={selectedInstallments}
            onValueChange={(value) => setSelectedInstallments(value)}>
            <Picker.Item label="3" value="3" />
            <Picker.Item label="4" value="4" />
            <Picker.Item label="6" value="6" />
          </Picker>
        </View>

        <View style={{ gap: 10 }}>
          <Text style={styles.label}>Punësim gjatë Kursit</Text>
          <View style={{ alignItems: 'flex-start' }}>
            <Switch
              trackColor={{ false: '#767577', true: '#c8c8d7' }}
              thumbColor={isEmployed ? '#0b1147' : '#c8c8d7'}
              disabled={selectedSubsidy == '50'}
              value={isEmployed}
              onValueChange={setIsEmployed}
            />
          </View>
        </View>

        {isEmployed && (
          <View style={{ gap: 10 }}>
            <Text style={styles.label}>Data e Punësimit</Text>
            <TouchableOpacity onPress={() => setShowEmploymentDatePicker(true)}>
              <Text style={styles.dateStyle}>
                {employmentDate.toLocaleDateString()}
              </Text>
            </TouchableOpacity>
            {showEmploymentDatePicker && (
              <DateTimePicker
                value={employmentDate}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={(_, selectedDate) => {
                  setShowEmploymentDatePicker(false);
                  if (selectedDate) setEmploymentDate(selectedDate);
                }}
              />
            )}
          </View>
        )}
        <TouchableOpacity
          onPress={calculate}
          disabled={validateValues()}
          style={{
            backgroundColor: validateValues() ? '#c8c8d7' : '#0b1147',
            paddingVertical: 5,
            alignItems: 'center',
            borderRadius: 5,
          }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'white' }}>
            Llogarit
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </>
  );
};

export default StudentInputScreen;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 10,
    gap: 10,
  },
  label: {
    fontWeight: '500',
    fontSize: 15,
  },
  inputStyle: {
    backgroundColor: '#c8c8d7',
    borderRadius: 5,
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  selectStyle: {
    backgroundColor: '#c8c8d7',
    borderColor: 'transparent',
  },
  dateStyle: {
    backgroundColor: '#c8c8d7',
    borderRadius: 5,
    paddingVertical: 14,
    paddingHorizontal: 12,
  },
});
