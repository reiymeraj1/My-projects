import {Text} from 'react-native'
import HeaderComponent from '../components/HeaderComponent'

const TraineeInputScreen = () => {
  return(
    <HeaderComponent canGoBack={false} />
  )
}

export default TraineeInputScreen
