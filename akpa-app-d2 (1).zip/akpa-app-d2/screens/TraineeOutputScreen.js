import {Text} from 'react-native'
import HeaderComponent from '../components/HeaderComponent'

const TraineeOutputScreen = () => {
  return(
    <HeaderComponent />
  )
}

export default TraineeOutputScreen